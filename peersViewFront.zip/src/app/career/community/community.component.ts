import {
  Component
} from '@angular/core';

@Component({
  selector: 'career-community-component',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.scss']
})
export class CareerCommunityComponent {
  constructor () {}
}
