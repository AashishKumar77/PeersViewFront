import {
  Component
} from '@angular/core';

@Component({
  selector: 'career-index-page-component',
  templateUrl: './index-page.component.html',
  styleUrls: ['./index-page.component.scss']
})
export class CareerIndexPageComponent {
  constructor () {}
}
