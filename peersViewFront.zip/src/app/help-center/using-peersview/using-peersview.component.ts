import {
  Component
} from '@angular/core';

@Component({
  selector: 'using-peersview-component',
  templateUrl: './using-peersview.component.html',
  styleUrls: ['./using-peersview.component.scss']
})
export class UsingPeersviewComponent {
  constructor () {


  }


}
