import {
  Component
} from '@angular/core';


@Component({
  selector: 'business-organization-component',
  templateUrl: './business-organization.component.html',
  styleUrls: ['./business-organization.component.scss']
})
export class BusinessOrganizationComponent {
  constructor  () {

  }

}
