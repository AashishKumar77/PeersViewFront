import {
  Component
} from '@angular/core';


@Component({
  selector: 'network-administrator-component',
  templateUrl: './network-administrator.component.html',
  styleUrls: ['./network-administrator.component.scss']
})
export class NetworkAdministratorComponent {
  constructor () {


  }


}
