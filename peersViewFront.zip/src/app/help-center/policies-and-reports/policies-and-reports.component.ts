import {
  Component
} from '@angular/core';

@Component({
  selector: 'policies-and-reports-component',
  templateUrl: './policies-and-reports.component.html',
  styleUrls: ['./policies-and-reports.component.scss']
})
export class PoliciesAndReportsComponent {
  constructor () {


  }


}
