import {
  Component
} from '@angular/core';

@Component({
  selector: 'employers-community-component',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.scss']
})
export class EmployersCommunityComponent {
  constructor () {}
}
