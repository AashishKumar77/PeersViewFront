import {
	Component,
	Input
} from '@angular/core';

@Component({
	selector: 'mobile-campus-nav-component',
	templateUrl: './mobile-campus-nav.component.html',
	styleUrls: ['./mobile-campus-nav.component.scss']
})
export class MobileCampusNavComponent {
	constructor () {}
}
