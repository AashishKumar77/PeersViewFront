import {
	Component,
  Input
} from '@angular/core';

@Component({
	selector: 'campus-right-sidebar-component',
	templateUrl: './right-sidebar.component.html',
	styleUrls: ['./right-sidebar.component.scss']
})
export class CampusRightSidebarComponent {
	constructor () {}
}
