import {
  Component,
  OnInit
} from '@angular/core';

@Component({
   selector: 'campus-component',
  templateUrl: './campus.component.html',
  styleUrls: ['./campus.component.scss']
})
export class CampusComponent implements OnInit {
  constructor () {}

  public ngOnInit (): void {}
}
