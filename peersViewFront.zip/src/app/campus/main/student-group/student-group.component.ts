import {
  Component,
} from '@angular/core';

@Component({
   selector: 'campus-student-group-component',
  templateUrl: './student-group.component.html',
  styleUrls: ['./student-group.component.scss']
})
export class CampusStudentGroupComponent {
  constructor () {}
}
