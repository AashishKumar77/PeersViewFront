import {
  Component
} from '@angular/core';

@Component({
  selector: 'campus-freshers-feed-component',
  templateUrl: './freshers-feed.component.html',
  styleUrls: ['./freshers-feed.component.scss']
})
export class CampusFreshersFeedComponent {
  constructor () {}
}
