import {
  Component,
} from '@angular/core';

@Component({
   selector: 'campus-marketplace-component',
  templateUrl: './marketplace.component.html',
  styleUrls: ['./marketplace.component.scss']
})
export class CampusMarketplaceComponent {
  constructor () {}
}
