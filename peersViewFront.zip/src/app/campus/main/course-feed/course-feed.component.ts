import {
  Component,
} from '@angular/core';

@Component({
   selector: 'campus-course-feed-component',
  templateUrl: './course-feed.component.html',
  styleUrls: ['./course-feed.component.scss']
})
export class CampusCourseFeedComponent {
  constructor () {}
}
