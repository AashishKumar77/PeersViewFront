import {
  Component,
  OnInit
} from '@angular/core';

@Component({
   selector: 'campus-admin-suspend-user-component',
  templateUrl: './suspend-user.component.html',
  styleUrls: ['./suspend-user.component.scss']
})
export class CampusAdminSuspendUserComponent implements OnInit {
  constructor () {}

  public ngOnInit (): void {}
}
