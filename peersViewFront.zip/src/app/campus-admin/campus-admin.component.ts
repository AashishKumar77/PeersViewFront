import {
  Component,
  OnInit
} from '@angular/core';

@Component({
   selector: 'campus-admin-component',
  templateUrl: './campus-admin.component.html',
  styleUrls: ['./campus-admin.component.scss']
})
export class CampusAdminComponent implements OnInit {
  constructor () {}

  public ngOnInit (): void {}
}
