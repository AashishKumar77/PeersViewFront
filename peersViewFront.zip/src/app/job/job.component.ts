import {
  Component,
  OnInit
} from '@angular/core';

@Component({
   selector: 'job-component',
  templateUrl: './job.component.html',
  styleUrls: ['./job.component.scss']
})
export class JobComponent implements OnInit {
  constructor () {}

  public ngOnInit (): void {}
}
