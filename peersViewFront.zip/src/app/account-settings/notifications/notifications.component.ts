import {
  Component
} from '@angular/core';

@Component({
  selector: 'account-settings-notifications-component',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class AccountSettingsNotificationsComponent {
  constructor () {}

  public ngOnInit (): void {}
}
