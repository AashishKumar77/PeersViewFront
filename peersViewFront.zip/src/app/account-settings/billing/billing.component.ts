import {
  Component
} from '@angular/core';

@Component({
  selector: 'account-settings-billing-component',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss']
})
export class AccountSettingsBillingComponent {
  constructor () {}

  public ngOnInit (): void {}
}
