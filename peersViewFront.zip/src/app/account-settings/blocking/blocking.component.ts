import {
  Component
} from '@angular/core';
import {
  UserModel
} from '../../shared/models';

@Component({
  selector: 'account-settings-blocking-component',
  templateUrl: './blocking.component.html',
  styleUrls: ['./blocking.component.scss']
})
export class AccountSettingsBlockingComponent {
  constructor () {}

  public ngOnInit (): void {}
}
