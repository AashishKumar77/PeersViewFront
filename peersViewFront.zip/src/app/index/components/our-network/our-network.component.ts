import {
  Component
} from '@angular/core';

@Component({
  selector: 'our-network-page-component',
  templateUrl: './our-network.component.html',
  styleUrls: ['./our-network.component.scss']
})
export class OurNetworkPageComponent {
  constructor () {}
}
