import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-leisure-page-component',
  templateUrl: './leisure-page.component.html',
  styleUrls: ['./leisure-page.component.scss']
})
export class IndexLeisurePageComponent {
  constructor () {}
}
