import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-community-page-component',
  templateUrl: './community-page.component.html',
  styleUrls: ['./community-page.component.scss']
})
export class IndexCommunityPageComponent {
  constructor () {}
}
