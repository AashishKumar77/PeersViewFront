import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-trending-now-page-component',
  templateUrl: './trending-now-page.component.html',
  styleUrls: ['./trending-now-page.component.scss']
})
export class IndexTrendingNowPageComponent {
  constructor () {}
}
