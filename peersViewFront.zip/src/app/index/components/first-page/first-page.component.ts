import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-first-page-component',
  templateUrl: './first-page.component.html',
  styleUrls: ['./first-page.component.scss']
})
export class IndexFirstPageComponent {
  constructor () {}
}
