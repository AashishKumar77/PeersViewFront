import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-sticky-navbar-component',
  templateUrl: './sticky-navbar.component.html',
  styleUrls: ['./sticky-navbar.component.scss']
})
export class IndexStickyNavbarComponent {
  constructor () {}
}
