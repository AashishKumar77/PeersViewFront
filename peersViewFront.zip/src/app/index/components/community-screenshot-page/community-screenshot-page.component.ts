import {
  Component
} from '@angular/core';

@Component({
  selector: 'index-community-screenshot-page-component',
  templateUrl: './community-screenshot-page.component.html',
  styleUrls: ['./community-scrennshot-page.component.scss']
})
export class IndexCommunityScreenshotPageComponent {
  constructor () {}
}
