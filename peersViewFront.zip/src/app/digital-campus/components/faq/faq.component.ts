import {
  Component
} from '@angular/core';

@Component({
  selector: 'digital-campus-faq-component',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class DigitalCampusFaqComponent {
  constructor () {}
}
