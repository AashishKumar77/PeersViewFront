import {
  Component
} from '@angular/core';

@Component({
  selector: 'digital-campus-instructors-component',
  templateUrl: './instructors.component.html',
  styleUrls: ['./instructors.component.scss']
})
export class DigitalCampusInstructorsComponent {
  constructor () {}
}
