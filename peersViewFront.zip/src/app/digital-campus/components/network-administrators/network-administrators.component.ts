import {
  Component
} from '@angular/core';

@Component({
  selector: 'digital-campus-network-administrators-component',
  templateUrl: './network-administrators.component.html',
  styleUrls: ['./network-administrators.component.scss']
})
export class DigitalCampusNetworkAdministratorsComponent {
  constructor () {}
}
