import {
  Component
} from '@angular/core';

@Component({
  selector: 'digital-campus-institutions-component',
  templateUrl: './institutions.component.html',
  styleUrls: ['./institutions.component.scss']
})
export class DigitalCampusInstititutionsComponent {
  constructor () {}
}
