import {
  Component
} from '@angular/core';

@Component({
  selector: 'about-us-index-page-component',
  templateUrl: './index-page.component.html',
  styleUrls: ['./index-page.component.scss']
})
export class AboutUsIndexPageComponent {
  constructor () {}
}
