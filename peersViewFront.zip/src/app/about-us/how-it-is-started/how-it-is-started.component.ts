import {
  Component
} from '@angular/core';

@Component({
  selector: 'about-us-how-it-is-started-component',
  templateUrl: './how-it-is-started.component.html',
  styleUrls: ['./how-it-is-started.component.scss']
})
export class AboutUsHowItIsStartedComponent {
  constructor () {}
}
