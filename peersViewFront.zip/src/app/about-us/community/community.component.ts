import {
  Component
} from '@angular/core';

@Component({
  selector: 'about-us-community-component',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.scss']
})
export class AboutUsCommunityComponent {
  constructor () {}
}
