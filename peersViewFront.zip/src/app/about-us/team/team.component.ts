import {
  Component
} from '@angular/core';

@Component({
  selector: 'about-us-team-component',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss']
})
export class AboutUsTeamComponent {
  constructor () {}
}
