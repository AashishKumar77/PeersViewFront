import {
	Component
} from '@angular/core';

@Component({
	selector: 'mobile-community-header-component',
	templateUrl: './mobile-header.component.html',
	styleUrls: ['./mobile-header.component.scss']
})

export class CommunityMobileHeader {
	constructor () {}
}
