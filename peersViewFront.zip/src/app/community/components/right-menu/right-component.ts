import {
	Component
} from '@angular/core';

@Component({
	selector: 'community-right-menu-component',
	templateUrl: './right-component.html',
	styleUrls: ['./right-component.scss']
})
export class CommunityRightMenuComponent {
	constructor () {}
}
