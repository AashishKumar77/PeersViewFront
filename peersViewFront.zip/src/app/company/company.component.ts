import {
  Component,
  OnInit
} from '@angular/core';

@Component({
   selector: 'company-component',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.scss']
})
export class CompanyComponent implements OnInit {
  constructor () {}

  public ngOnInit (): void {}
}
