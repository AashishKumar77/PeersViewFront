import {
	Component,
	Input
} from '@angular/core';

@Component({
	selector: 'mobile-create-ad-nav-component',
	templateUrl: './mobile-create-ad-nav.component.html',
	styleUrls: ['./mobile-create-ad-nav.component.scss']
})
export class MobileCreateAdNavComponent {
	constructor () {}
}
